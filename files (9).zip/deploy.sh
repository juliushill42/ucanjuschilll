#!/bin/bash
set -e

PROJECT="ucanjuschill-prod"
ZONE="us-central1-a"

echo "=== UCANJUSCHILL DEPLOY ==="

# Set project
gcloud config set project $PROJECT

# Clean old terraform state
rm -rf .terraform terraform.tfstate* .terraform.lock.hcl

# Auth fix for Terraform
export GOOGLE_OAUTH_ACCESS_TOKEN=$(gcloud auth print-access-token)

# Enable required APIs
echo "[1/4] Enabling APIs..."
gcloud services enable compute.googleapis.com --project=$PROJECT

# Terraform init + apply
echo "[2/4] Provisioning VM..."
terraform init
terraform apply -auto-approve

# Get IP
IP=$(terraform output -raw instance_ip)
echo "[3/4] VM IP: $IP"
echo ""
echo "[4/4] DONE. Site will be live at http://$IP in ~3 minutes"
echo "      (VM is pulling repo and starting Docker)"
echo ""
echo "SSH in with: gcloud compute ssh juliushill@ucanjuschill-app --zone=$ZONE --project=$PROJECT"
