terraform {
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.0" }
  }
}

provider "google" {
  project = "ucanjuschill-prod"
  region  = "us-central1"
  zone    = "us-central1-a"
}

resource "google_compute_firewall" "allow_web" {
  name    = "ucanjuschill-allow-web"
  network = "default"
  allow { protocol = "tcp"; ports = ["22", "80", "443", "3000", "8080"] }
  source_ranges = ["0.0.0.0/0"]
}

resource "google_compute_instance" "app" {
  name         = "ucanjuschill-app"
  machine_type = "e2-standard-4"
  zone         = "us-central1-a"

  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size  = 50
    }
  }

  network_interface {
    network = "default"
    access_config {}
  }

  metadata_startup_script = <<-SCRIPT
    #!/bin/bash
    apt-get update -y
    apt-get install -y docker.io docker-compose git
    systemctl enable docker
    systemctl start docker
    usermod -aG docker juliushill

    cd /opt
    git clone https://github.com/juliushill42/ucanjuschill.git app
    cd app
    docker-compose up -d --build
  SCRIPT

  tags = ["http-server", "https-server"]
}

output "instance_ip" {
  value = google_compute_instance.app.network_interface[0].access_config[0].nat_ip
}
